import java.util.Scanner;
import static java.lang.System.out;

public class GuoweiAlt
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);

    int cases = Integer.parseInt(sc.nextLine());

    String[] output = new String[cases];

    int index = 0;

    for (int i = 0; i < cases; i++)
    {
      int shift = Integer.parseInt(sc.nextLine());
      String phrase = sc.nextLine() + " ";

      char[] toShift = phrase.toCharArray();

      for (int j = 0; j < shift; j++)
      {
        int k = 0;

        while (k < toShift.length-1)
        {
          char tmp = toShift[k];
          toShift[k] = toShift[k+1];
          toShift[k+1] = tmp;

          k++;
        }
      }

      String display = "";
      for (char character : toShift)
        display += character + "";
      display = display.substring(0, 40);

      output[index] = display;
      index++;
    }

    for (String result : output)
      out.println(result);

    sc.close();
  }
}
